USE realstate_crm; SELECT * FROM tasks WHERE due_date =  2025-06-23 AND status = Pending;
